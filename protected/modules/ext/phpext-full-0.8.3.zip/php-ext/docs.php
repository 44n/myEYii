   
    
    <h2 style="margin-bottom:5px;">PHP-Ext Documentation</h2>
	<p class="justified"></a>Need an API reference? Check out the quick online reference or download it to work offline.  
	The documentation its not complete yet (I mean types and descriptions), but you can check for classes, methods and properties for
	the whole library. 
	</p>
	<p class="justified">
	<h4>PHP-Ext 0.8.3 API Documentation</h4>	
	<a href="docs/api" style="margin-left: 10px;">View Online</a><br>	
	<a href="docs/PHP-Ext 0.8.3 API Documentation.chm" style="margin-left: 10px;">Download CHM File</a><br>
	<br>
	<h4>PHP-Ext Programming Reference</h4>
	Comming soon...For now please check out the <a href="examples">Samples Page</a>.
	</p>	
	
	<p class="justified">
	<h4>Ext 2.0 Reference</h4>	
	<a href="http://extjs.com/deploy/dev/docs/" style="margin-left: 10px;">API Documentation</a><br>		
	</p>
	
