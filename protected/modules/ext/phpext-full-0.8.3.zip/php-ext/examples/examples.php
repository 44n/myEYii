<h2 style="margin-bottom:5px;">Samples</h2>
	<p class="justified">Welcome to the sample page.  Here you will find simple and not that simple examples
	of common scenarios where you can use PHP-Ext.  On each example, you can click on the <i>"View PHP Source"</i> button to view the php code
	for the sample you are viewing.  Also if you are that courious you can click on <i>"View Generated JS"</i> button 
	to view the output javascript from the php script. 
	</p>
	<p class="justified">The first goal is to implement all of the samples in the
	<a href="http://extjs.com/deploy/dev/examples/">Ext Samples Page</a>, but if you think there's a sample missing 
	to better show the library's capabilities feel free to suggest.
	</p>	
	<p class="justified"><b>Click on the samples on the left bar to start enjoying.</b> 
	</p>